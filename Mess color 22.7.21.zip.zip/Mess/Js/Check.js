var date = new Date();
date = date.getDate() + "/" + (date.getMonth()+1) + "/" + date.getFullYear()

var alalarr = []
var alalobj = {}
var alalstore = JSON.parse(localStorage.getItem('alalarr'))

var alimarr = []
var alimobj = {}
var alimstore = JSON.parse(localStorage.getItem('alimarr'))

var display = document.getElementById('display')
var input = document.getElementById('input')
var total = document.getElementById('total')
var poneval = document.getElementById('pone')
var alalradio = document.getElementById('alalradio')
var alimradio = document.getElementById('alimradio')
var alalzero = document.getElementById('alalzero')
var alimzero = document.getElementById('alimzero')

// calculated view ---------------

var tval = Number(localStorage.getItem('total'))
var alalget = Number(localStorage.getItem('alalval'))
var alimget = Number(localStorage.getItem('alimval'))

  total.innerHTML = tval.toFixed(2)
  alalzero.innerHTML = alalget.toFixed(2)
  alimzero.innerHTML = alimget.toFixed(2)

var pvalt = tval / 2
    localStorage.setItem('poneval', pvalt)
 var pval = Number(localStorage.getItem('poneval'))
poneval.innerHTML = pval.toFixed(2)

if (alalget < pval) {
  document.getElementById('alaldue').innerHTML = `ALAL DUE <span style="font-size:130%;color:red;font-weight:900;">${Number(pval-alalget).toFixed(2)}</span> QAR TO ALIM`
}
if (alimget < pval) {
  document.getElementById('alimdue').innerHTML= `ALIM DUE <span style="font-size:130%;font-weight:900;color:red;">${Number(pval-alimget).toFixed(2)}</span> QAR TO ALAL`
}
 
 // Delete cell function ----------
 
function alaldelarr (alaldx) {
  var delvalttl = tval - alalstore[alaldx].value
   localStorage.setItem('total', delvalttl)
   var delvalal = alalget - alalstore[alaldx].value
   localStorage.setItem('alalval', delvalal)
   alalstore.splice(alaldx, 1)
   localStorage.setItem('alalarr', JSON.stringify(alalstore))
   location.reload()
 }
 
function alimdelarr(alimdx) {
var delvalttl = tval - alimstore[alimdx].value
   localStorage.setItem('total', delvalttl)
   var delvalim = alimget - alimstore[alimdx].value
   localStorage.setItem('alimval', delvalim)
   alimstore.splice(alimdx, 1)
   localStorage.setItem('alimarr', JSON.stringify(alimstore))
   location.reload()
 }

// add cost function -------------

document.getElementById('submit').addEventListener('click', () => {

  if (alalradio.checked && input.value) {
    var nval = Number(input.value)
    tval += nval
    localStorage.setItem('total', tval)
    alalget += Number(input.value)
    localStorage.setItem('alalval', alalget)
    ponev = tval / 2
    localStorage.setItem('poneval', ponev)
    
// arry & table (alal) ----------

if (alalstore) {
  alalobj.date = date
  alalobj.value = input.value
  alalstore.push(alalobj)
  localStorage.setItem('alalarr', JSON.stringify(alalstore))
} 
else{
  alalobj.date = date
  alalobj.value = input.value
  alalarr.push(alalobj)
  localStorage.setItem('alalarr', JSON.stringify(alalarr))
}
input.value = ""
    location.reload()
  }
  else if (alimradio.checked && input.value) {
    var nval = Number(input.value)
    tval += nval
    localStorage.setItem('total', tval)
    alimget += Number(input.value)
    localStorage.setItem('alimval', alimget)
    ponev = tval / 2
    localStorage.setItem('poneval', ponev)

 // arry & table (alim) ----------
 
  if (alimstore) {
  alimobj.date = date
  alimobj.value = input.value
  alimstore.push(alimobj)
  localStorage.setItem('alimarr', JSON.stringify(alimstore))
} 
else{
  alimobj.date = date
  alimobj.value = input.value
  alimarr.push(alimobj)
  localStorage.setItem('alimarr', JSON.stringify(alimarr))
}
     input.value = ""
    location.reload()
  }
else {
   alert("Please Check The Field!")
    input.value = ""
  }
})
  // table view (alal) -------------
  
  if (alalstore) {
    alalstore.forEach((alals, alaldx) => {
      var newRow = display.insertRow()
      var cell1 = newRow.insertCell()
      var cell2 = newRow.insertCell()
      var cell3 = newRow.insertCell()
      var cell4 = newRow.insertCell()
      cell1.innerHTML = `ALAL`
      cell2.innerHTML = alalstore[alaldx].date
      cell3.innerHTML = alalstore[alaldx].value
      cell4.innerHTML = `<button id="delarr" onclick="alaldelarr(${alaldx})">X</button>`
    })
  } else {
    alalarr = []
  }
  
  // table view (alim) -------------
  
  if (alimstore) {
    alimstore.forEach((alims, alimdx) => {
      var newRow = display.insertRow()
      var cell1 = newRow.insertCell()
      var cell2 = newRow.insertCell()
      var cell3 = newRow.insertCell()
      var cell4 = newRow.insertCell()
      cell1.innerHTML = `ALIM`
      cell2.innerHTML = alimstore[alimdx].date
      cell3.innerHTML = alimstore[alimdx].value
      cell4.innerHTML = `<button id="delarr" onclick="alimdelarr(${alimdx})">X</button>`
    })
  } else {
    alimarr = []
  }

// reset button ----------------

document.getElementById('resetbtn').addEventListener('click', () => {
  localStorage.setItem('total',   0)
  localStorage.setItem('poneval', 0)
  localStorage.setItem('alalval', 0)
  localStorage.setItem('alimval', 0)
  alalarr = []
  localStorage.setItem('alalarr', JSON.stringify(alalarr))
  alimarr = []
  localStorage.setItem('alimarr', JSON.stringify(alimarr))
 location.reload()
 
})